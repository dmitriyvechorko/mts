create function get_costs_by_date(p_date date)
    returns TABLE(settlement_name character varying, cost_date date, standard_cost_per_min numeric, discounted_cost_per_min numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            settlement_name,
            date AS cost_date,
            cost_per_min,
            preferential_cost
        FROM
            Cost
        WHERE
            date = p_date;
END;
$$;

alter function get_costs_by_date(date) owner to postgres;

