create function create_receipt_after_call_insert() returns trigger
    language plpgsql
as
$$
DECLARE
    regular_cost DECIMAL(10, 2) := 0.00;  -- Устанавливаем стоимость по умолчанию
    preferential_cost DECIMAL(10, 2) := 0.00; -- Устанавливаем стоимость по умолчанию
    total_cost DECIMAL(10, 2);
    cost_id INT := 0;  -- Устанавливаем значение по умолчанию для cost_id
    call_duration_minutes INT;
    call_time TIME;
BEGIN
    -- Получаем cost_id и стоимость для города, учитывая дату звонка
    SELECT c.id, c.cost_per_min, c.preferential_cost
    INTO cost_id, regular_cost, preferential_cost
    FROM Cost c
    WHERE c.settlement_name = NEW.city_called_to
      AND c.date <= NEW.date_of_call::DATE
    ORDER BY c.date DESC
    LIMIT 1;

    -- Если не нашли стоимость для города, то оставляем значение по умолчанию
    -- Стоимость уже по умолчанию равна 0.00
    IF cost_id = 0 THEN
        total_cost := 0.00;
    ELSE
        -- Вычисляем длительность звонка в минутах
        call_duration_minutes := EXTRACT(EPOCH FROM NEW.call_duration) / 60;

        -- Получаем время звонка (только время из date_of_call)
        call_time := NEW.date_of_call::TIME;

        -- Определяем, попадает ли звонок в льготный период (с 20:00 до 6:00)
        IF call_time BETWEEN '20:00:00' AND '23:59:59' OR call_time BETWEEN '00:00:00' AND '06:00:00' THEN
            -- Льготная стоимость
            total_cost := call_duration_minutes * preferential_cost;
        ELSE
            -- Обычная стоимость
            total_cost := call_duration_minutes * regular_cost;
        END IF;
    END IF;

    -- Вставляем запись в таблицу Receipt (по умолчанию, квитанция не оплачена)
    INSERT INTO Receipt (conversation_id, receipt_date, cost_id, total_cost, paid)
    VALUES (NEW.id, NOW(), cost_id, total_cost, FALSE);  -- оплачено по умолчанию false

    -- Возвращаем NEW, чтобы триггер работал нормально
    RETURN NEW;
END;
$$;

alter function create_receipt_after_call_insert() owner to postgres;

