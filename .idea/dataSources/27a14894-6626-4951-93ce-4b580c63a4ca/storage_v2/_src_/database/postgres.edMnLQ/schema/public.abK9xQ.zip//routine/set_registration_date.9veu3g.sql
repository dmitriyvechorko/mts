create function set_registration_date() returns trigger
    language plpgsql
as
$$
BEGIN
    IF TG_OP = 'INSERT' THEN
        NEW.registration_date := CURRENT_DATE;
    END IF;
    RETURN NEW;
END;
$$;

alter function set_registration_date() owner to postgres;

