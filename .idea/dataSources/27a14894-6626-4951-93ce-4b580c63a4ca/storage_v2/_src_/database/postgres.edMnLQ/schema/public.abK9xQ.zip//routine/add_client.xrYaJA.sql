create procedure add_client(IN full_name character varying, IN address character varying)
    language plpgsql
as
$$
BEGIN
    INSERT INTO Client (full_name, address)
    VALUES (full_name, address);
END;
$$;

alter procedure add_client(varchar, varchar) owner to postgres;

