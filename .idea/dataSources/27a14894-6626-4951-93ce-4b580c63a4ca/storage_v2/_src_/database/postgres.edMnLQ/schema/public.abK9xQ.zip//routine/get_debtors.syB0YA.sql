create function get_debtors()
    returns TABLE(client_name character varying, client_address character varying, service_date date, city_providing_service character varying, phone_number character varying, receipt_date date)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            c.full_name AS client_name,
            c.address AS client_address,
            cl.date_of_call::DATE AS service_date,
            cl.city_called_to AS city_providing_service,
            cl.phone_number AS phone_number,
            r.receipt_date AS receipt_date
        FROM
            Client c
                JOIN
            Call cl ON cl.client_id = c.id
                JOIN
            Receipt r ON r.conversation_id = cl.id
        WHERE
            r.paid = FALSE
          AND r.receipt_date <= CURRENT_DATE - INTERVAL '20 days'
        ORDER BY
            r.receipt_date;
END;
$$;

alter function get_debtors() owner to postgres;

